# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '18a86bdcd55e007a65f507e056beb5503ab51887e4212acc1702a42c8e3076ead4db16d00c254ff27a459c2f7f3badcec0bea371f3dd606e0a713d917e5ba048'